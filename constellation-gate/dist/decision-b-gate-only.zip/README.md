# Decision B — Gate-only idempotency-key remediation

This bundle contains the **Gate-only** resolution of the `TransportPacket.derive(idempotency_key=...)`
contract drift, chosen because this run had **no push access to `Quantum-L9/Gate_SDK`**
(`permissions.push = false`), so the SDK's `derive()` could not be extended.

## The problem

`constellation-node-sdk`'s `TransportPacket.derive()` inherits the parent's
`idempotency_key` and does **not** accept an override. But `DelegationFactory.build()`
(and two tests) assumed `derive(idempotency_key=...)` worked, causing:

```
TypeError: TransportPacket.derive() got an unexpected keyword argument 'idempotency_key'
```

## The Gate-only fix (no SDK change required)

- `src/constellation_gate/boundary/delegation_factory.py`
  - Adds `_apply_idempotency_key(packet, key)`, which re-finalizes a derived child
    packet's transport hash using the SDK's **public** `compute_transport_hash`
    helper so the delegated packet can carry its own idempotency key while
    remaining integrity-valid. (Payload and payload_hash are unchanged.)
  - `build()` derives the child, then applies the key only when one is provided
    and differs from the inherited value.
  - Also parameterizes the `payload: dict` argument as `dict[str, Any]` (mypy).
- `tests/services/test_execute_service_idempotency.py` and
  `tests/resilience/test_idempotency.py`
  - Obtain a keyed packet via `create_transport_packet(..., idempotency_key="abc")`
    instead of `.derive(idempotency_key="abc")` — an equivalent, frozen-SDK-compatible
    expression of the same intent.

## Contents

- `files/` — the three changed files at their `constellation-gate/`-relative paths
  (drop-in replacements).
- `decision-b-gate-only.patch` — a `git`-applyable diff (paths relative to the
  `constellation-gate/` package directory).

## How to apply / push

From the `constellation-gate/` directory of a checkout:

```bash
# Option A: apply the patch
git apply /path/to/decision-b-gate-only.patch
# (or: git apply --3way decision-b-gate-only.patch)

# Option B: copy the files in
cp -r /path/to/files/. .

# then verify + commit + push
ruff check src tests && mypy src && pytest -q \
  tests/services/test_execute_service_idempotency.py \
  tests/resilience/test_idempotency.py \
  tests/boundary/test_delegation_factory.py
git add src/constellation_gate/boundary/delegation_factory.py \
        tests/services/test_execute_service_idempotency.py \
        tests/resilience/test_idempotency.py
git commit -m "fix(gate): carry delegated idempotency key without SDK derive() override"
git push
```

> Note: these exact changes are already included in remediation PR #3
> (branch `cursor/ci-remediation-676e`). This bundle is a standalone extract of
> just the Decision B portion for separate review/pushing.

## If you instead want the SDK-side fix

If you have push access to `Quantum-L9/Gate_SDK` and prefer the cleaner fix,
add an optional `idempotency_key: str | None = None` parameter to
`TransportPacket.derive()` in `src/constellation_node_sdk/transport/packet.py`
(set `idempotency_key=idempotency_key or self.header.idempotency_key` in the new
`TransportHeader`), release/pin a new SDK commit, then revert
`_apply_idempotency_key` back to a plain `derive(idempotency_key=...)` call in
Gate. That path is **not** included here because it belongs in the SDK repo.
